#include <linux/mm.h>

static struct page *LinuxDriverNoPage(struct vm_area_struct *vma,
                           unsigned long address, int *type) {
	(void)vma;
	(void)address;
	*type = VM_FAULT_MAJOR;
	return NULL;
}

struct vm_operations_struct vmuser_mops = {
        .nopage = LinuxDriverNoPage
};
