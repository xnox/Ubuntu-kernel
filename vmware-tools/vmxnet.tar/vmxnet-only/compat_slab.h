#ifndef __COMPAT_SLAB_H__
#   define __COMPAT_SLAB_H__


#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 2, 0)
#   include <linux/slab.h>
#else
#   include <linux/malloc.h>
#endif

#endif /* __COMPAT_SLAB_H__ */
