/* **********************************************************
 * Copyright 2004 VMware, Inc.  All rights reserved.
 * **********************************************************/

/*
 * vmdesched_core.h --
 *
 *      Exports the init. and cleanup functions needed by
 *      os.c/os.h.
 */

#ifndef _VMDESCHED_CORE_H_
#define _VMDESCHED_CORE_H_

#define CDECL __attribute__((cdecl, regparm(0)))

extern int  CDECL VmDesched_Init(void);
extern void CDECL VmDesched_Exit(void);

#endif
