/*
 * Detect whether we have 'struct poll_wqueues'
 */

#include <linux/poll.h>

void poll_test(void) {
        struct poll_wqueues test;

        return poll_initwait(&test);
}
