#include <linux/sched.h>

void test(void) {
   set_user_nice(current, -20);
}

