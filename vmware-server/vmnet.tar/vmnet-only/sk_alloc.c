/*
 * Detect whether sk_alloc takes a struct proto * as third parameter.
 * This API change was introduced between 2.6.12-rc1 and 2.6.12-rc2.
 */

#include <net/sock.h>

static struct proto test_proto = {
   .name     = "TEST",
};

struct sock * 
vmware_sk_alloc(void)
{
   return sk_alloc(PF_NETLINK, 0, &test_proto, 1);
}
