#ifndef __COMPAT_KDEV_T_H__
#   define __COMPAT_KDEV_T_H__


#include <linux/kdev_t.h>


/* The major() API appeared in 2.5.2 --hpreg */
#ifndef major
#   define major MAJOR
#   define minor MINOR
#endif


#endif /* __COMPAT_KDEV_T_H__ */
