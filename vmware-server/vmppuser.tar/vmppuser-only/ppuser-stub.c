/*
 * Copyright 1998 VMware, Inc.  All rights reserved. -- VMware Confidential
 *
 * This stub selects either Linux 2.2 compatible ppuser or
 * Linux 2.3 ppdev.
 *
 */

#include "driver-config.h"

#include <linux/version.h>

#define VMWARE

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,3,10)
#include "ppuser.c"
#else
#include "ppdev.c"
#endif
