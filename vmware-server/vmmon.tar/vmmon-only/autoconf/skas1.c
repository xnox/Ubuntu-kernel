/*
 * SKAS patch adds 'struct mm *mm' as first argument to do_mmap_pgoff.
 */

#include <linux/mm.h>

unsigned long check_do_mmap_pgoff(struct mm_struct *mm, struct file *file,
				  unsigned long addr, unsigned long len,
				  unsigned long prot, unsigned long flag,
				  unsigned long pgoff) {
   return do_mmap_pgoff(mm, file, addr, len, prot, flag, pgoff);
}

