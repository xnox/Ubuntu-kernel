/* **********************************************************
 * Copyright 1998 VMware, Inc.  All rights reserved. -- VMware Confidential
 * **********************************************************/



#ifndef TASK_H
#define TASK_H

#define INCLUDE_ALLOW_VMMON
#define INCLUDE_ALLOW_VMCORE
#include "includeCheck.h"

struct InitBlock;

extern int Task_InitCrosspage(VMDriver *vm, struct InitBlock *params);
extern void Task_Switch(VMDriver *vm, Vcpuid vcpuid);
extern Bool Task_TemporaryGDTInitialize(void);
extern void Task_TemporaryGDTFinalize(void);
#endif



