/* **********************************************************
 * Copyright 2004 VMware, Inc.  All rights reserved. -- VMware Confidential
 * **********************************************************/

#ifndef _DRIVER_VMCORE_H_
#define _DRIVER_VMCORE_H_

#define INCLUDE_ALLOW_VMMON
#define INCLUDE_ALLOW_VMCORE
#include "includeCheck.h"

#include "vmx86.h"

/*
 * Exported vmcore functions.
 */

int Vmx86_RunVM(VMDriver *vm, Vcpuid vcpuid);
void Vmx86_AckUserCall(VMDriver *vm, Vcpuid vcpuid);
void Vmx86_CompleteUserCall(VMDriver *vm, Vcpuid vcpuid);

#endif
