/* **********************************************************
 * Copyright 2003 VMware, Inc.  All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

#ifndef _MACHINE_H_
#define _MACHINE_H_

#define INCLUDE_ALLOW_VMX
#define INCLUDE_ALLOW_VMMEXT
#define INCLUDE_ALLOW_MODULE
#define INCLUDE_ALLOW_VMMON
#define INCLUDE_ALLOW_VMCORE
#include "includeCheck.h"

#include "vm_basic_types.h"

/* machine dependent definitions */
#ifdef VM_IA64
#include "ia64.h"
#endif

#ifdef VM_I386
#include "x86.h"
#endif

/* machine independent definitions */

#endif // _MACHINE_H_
