/* **********************************************************
 * Copyright 2001 VMware, Inc.  All rights reserved. -- VMware Confidential
 * **********************************************************/

/*
 * pshare_ext.h --
 *
 *	VMKernel/VMMon <-> VMM transparent page sharing info.
 */

#ifndef _PSHARE_EXT_H
#define _PSHARE_EXT_H

#define INCLUDE_ALLOW_USERLEVEL
#define INCLUDE_ALLOW_VMMEXT
#define INCLUDE_ALLOW_VMKERNEL
#define INCLUDE_ALLOW_VMMON
#define INCLUDE_ALLOW_VMNIXMOD
#define INCLUDE_ALLOW_VMCORE
#include "includeCheck.h"

/*
 * constants
 */

#define PSHARE_BATCH_PAGES_MAX          (450) //sizeof(PShare_List) < PAGE_SIZE

#define PSHARE_DEFAULT_SCAN_RATE        (32)

#define PSHARE_P2M_BUFFER_MPNS_MAX      (8)
#define PSHARE_P2M_BUFFER_MPNS_DEFAULT  (2)
#define	PSHARE_P2M_UPDATES_MAX		(64)
#define	PSHARE_P2M_UPDATES_OVERFLOW	(-1)
#define	PSHARE_HINT_UPDATES_MAX		(PSHARE_BATCH_PAGES_MAX)
#define PSHARE_HINT_BATCH_PAGES_MAX     (32)
#define PSHARE_P2M_BUFFER_SLOTS_PER_MPN ((PAGE_SIZE/sizeof(PShare_P2MUpdate)))

#define PSHARE_MAX_COW_CHECK_PAGES      (16) // limited by rpc block size
#define PSHARE_DEFAULT_CHECK_RATE       (16) 

#ifdef VMX86_SERVER
#define ZERO_MPN_MAX                    (8)
#else
#define ZERO_MPN_MAX                    (1)
#endif

/*
 * types
 */

typedef struct PShare_List {
   BPN     bpnList[PSHARE_BATCH_PAGES_MAX];
   MPN     mpnList[PSHARE_BATCH_PAGES_MAX];
   Bool    hintOnlyList[PSHARE_BATCH_PAGES_MAX];
} PShare_List;

typedef struct PShare_P2MUpdate {
   BPN     bpn;
   MPN     mpn;
} PShare_P2MUpdate;

typedef enum {
   PSHARE_HINT_NONE,
   PSHARE_HINT_STALE,
   PSHARE_HINT_MATCH
} PShare_HintStatus;

typedef struct PShare_HintUpdate {
   BPN               bpn;
   PShare_HintStatus status;
} PShare_HintUpdate;

typedef struct {
   uint32 nScan;	// pages scanned
   uint32 nAttempt;	// page sharing attempts
   uint32 nCOW;		// pages marked COW
   uint32 nHint;	// pages marked COW hint
   uint32 nShare;	// pages shared
   uint32 nCopy;	// pages copied

   uint32 nCheck;	// pages checked
   uint32 nCheckBad;	// page check failures
   uint32 nCheckBadKey;	// hash key check mismatches
   uint32 nCheckBadMPN;	// MPN check mismatches
   uint32 nCheckBadCOW;	// COW check mismatches
} PShare_MonitorStats;

typedef struct PShare_COWCheckInfo {
   BPN     bpn;        // bpn to check
   MPN     vmmMPN;     // mpn for this page in monitor
   MPN     hostMPN;    // mpn for this page in the host
   Bool    vmmCOW;     // cow state of this page in monitor
   Bool    hostCOW;    // cow state of this page in the host
   Bool    keyOK;
   Bool    checkOK;
} PShare_COWCheckInfo;

typedef struct PShare_ZeroMPNInfo {
   // VMK/VMX -> VMM
   uint32 numEntries;
   MPN    list[ZERO_MPN_MAX];
} PShare_ZeroMPNInfo;

#endif
