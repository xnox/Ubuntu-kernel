/*
 * Detect whether there is 'sk_wmem_alloc' member in 'sock'
 */

#include <net/sock.h>

void *sock_wmem_alloc_test(struct sock* sk) {
	return &sk->sk_wmem_alloc;
}
